import React { Components,Fragment } from 'react'

function config() {
const config = {
  "apiUrl":"https://api.exchangeratesapi.io/latest",
  "baseCurrency":"USD",
  "ENV":"development",
  "currencyDropdown":["USD","CAD","IDR","GBP","CHF","SGD","INR","MYR","JPY","KRW"]  
}

module.exports = config;
}
export default config