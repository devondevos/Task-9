import React, { Component,Fragment } from 'react';
import Dropdown from 'react-dropdown'
import Button from 'react-bootstrap/Button'
import Converter from './Components/Converter1'
import Card from './Components/Card'
import './App.css'

function App() {
	const options = [
	'', 'Currency Converter', 'Win!'
]
  return (
  	<div className="App">
  		<header className="App-header">
  			<h1>devondevos.co.za</h1>
  		</header>
  		<main className="App-body">
  		  <div>
  		    <Dropdown className="dropDown" options={options} placeholder="Select a project" />
  		  </div>
        <div className="Converter">
          <Converter />
        </div>
        <div className="Win">
          <Card /> <br/>
        </div>
      </main>
    </div>
  );
}

export default App;
