import React, { Component } from "react";

class Converter1 extends Component {
  state = {
    currencies: ["USD", "ZAR", "GBP", "EUR"],
    base: "USD",
    amount: "",
    convertTo: "ZAR",
    convertTo2: "GBP",
    convertTo3: "EUR",
    result: "",
    result2: "",
    result3: "",
    date: ""
  };
  handleSelect = e => {
    this.setState(
      {
        [e.target.name]: e.target.value,
        result: null
      },
      this.calculate
    );
  };

  handleInput = e => {
    this.setState(
      {
        amount: e.target.value,
        result: null,
        result2: null,
        result3: null,
        date: null
      },
      this.calculate
    );
  };

  calculate = () => {
    const amount = this.state.amount;
    if (amount === isNaN) {
      return;
    } else {
      fetch(`https://api.exchangeratesapi.io/latest?base=${this.state.base}`)
        .then(res => res.json())
        .then(data => {
          const date = data.date;
          const result = (data.rates[this.state.convertTo] * amount).toFixed(4);
          const result2 =(data.rates[this.state.convertTo2] * amount).toFixed(4);
          const result3 = (data.rates[this.state.convertTo3] * amount).toFixed(4);
          this.setState({
            result, result2, result3,
            date
          });
        });
    }
  };
  render() {
    const { currencies, base, amount, convertTo, result, result2, result3, date } = this.state;
    return (
      <div className="container my-5">
        <div className="row">

          <div className="col-lg-6 mx-auto">
            <div className="card card-body">
              <div className="row">
                <div className="col-lg-10">
                  <form className="form-inline mb-4">
                  	<h4>USD (Dollar)</h4>
                    <input
                      type="number"
                      value={amount}
                      onChange={this.handleInput}
                      className="form-control form-control-lg mx-3"
                    /> {/*use bootstrap to create columns in React js*/}
                  </form>
                  <form className="form-inline mb-4">
                  	<h4>ZAR (Rand)</h4>
                    <input
                      disabled={true}
                      value={
                        amount === ""
                          ? "0"
                          : result === null
                          ? "Calculating..."
                          : result
                      }
                      className="form-control form-control-lg mx-3"
                    />
                  </form>
                  <form className="form-inline mb-4">
                    <h4>GBP (Pound)</h4>
                    <input
                      disabled={true}
                      value={
                        amount === ""
                          ? "0"
                          : result2 === null
                          ? "Calculating..."
                          : result2
                      }
                      className="form-control form-control-lg mx-3"
                    />
                  </form>
                  <form className="form-inline mb-4">
                    <h4>EUR (Euro)</h4>
                    <input
                      disabled={true}
                      value={
                        amount === ""
                          ? "0"
                          : result3 === null
                          ? "Calculating..."
                          : result3
                      }
                      className="form-control form-control-lg mx-3"
                    />
                  </form>
                </div>
              </div>
            </div>
          </div>

        </div>
      </div>
    );
  }
}

export default Converter1;
