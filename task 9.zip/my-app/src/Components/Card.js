import React from 'react'
import Card1 from './Card1'
import Card2 from './Card2'
import Card3 from './Card3'
import './card.css'



function Card() {
var cardText = ["You win","Unlucky...","Try Again...","Better Luck next time...","Almost got it..."]
var randomText = Math.floor(cardText.length*Math.random())
  return(
    <div className="cardContainer">
      <div className="card1">
        <Card1 name={cardText[randomText]}/>
      </div>
      <div className="card1">
        <Card2 name={cardText[randomText]}/>
      </div>
      <div className="card1">
        <Card3 name={cardText[randomText]}/> {/*call them in your functions*/}
      </div>
    </div>
  )
}

export default Card