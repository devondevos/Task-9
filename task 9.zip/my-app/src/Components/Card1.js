import React, { Component } from 'react';
// Used for flipping card animation.
import ReactCardFlip from 'react-card-flip';
import Image from './cardBackground.png';
class Card1 extends React.Component {
   constructor() {
       super();
       this.state = {
           // This keeps the card facing the front
           isFlipped: false,
           clicked: false
       };
       // Binding the state
       this.handleClick = this.handleClick.bind(this);
   }
   // This function below prompts the user to 'try again' or 'exit' and then depending on their choice will either refresh the page or go the home page.
   tryOrQuit = (event) => {
       event = prompt(this.props.winOrLose + "\n\n1. Try again?\n2. Exit?", "Choose 1 or 2 and press enter!");
       if (event == 1) {
           window.location.reload();
       } else {
           window.location.pathname = "/";
       }
   };
   // This function changes the state of the card and also calls a timed function
   handleClick(e) {
       e.preventDefault();
       this.setState(prevState => ({ isFlipped: !prevState.isFlipped }));
       // this function calls "tryOrQuit" function at a specific time (300 millieseconds in this case)
       setTimeout(this.tryOrQuit, 300);
   }
  render() {
    return (
      <ReactCardFlip isFlipped={this.state.isFlipped} flipDirection="vertical" flipSpeedFrontToBack={0.3} flipSpeedBackToFront={0.3}>
        <div onClick={this.handleClick}  key="front" className="myCards">
          <img src={Image}/>
        </div>
 
        <div className="myCards" key="back">
          <h3>{this.props.name}</h3>
        </div>
      </ReactCardFlip>
    )
  }
}
export default Card1;